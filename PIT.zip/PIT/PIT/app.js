var app= angular.module("myApp",["ngRoute"]);
app.factory("myFactory", function(){
    var obj={};
    var detail={};
    obj.setval=function(user){
        detail.name=user.fname+" " +user.lname;
        detail.age=user.age;
        detail.email=user.email;
        detail.tel=user.tel;
        detail.state=user.state;
        detail.country=user.country;
        detail.address=user.address1+user.address2;
        detail.interests=user.interests;
        detail.news=user.newsletter;
        detail.src=user.src;
    };
    obj.getval=function(){
        return detail;
    };
    return obj;
});

app.config(function($routeProvider) {
    $routeProvider
    .when("/", {
        templateUrl : "partials/register.html",
        controller:"registerController"
    })
    .when("/form", {
        templateUrl : "partials/data.html",
        controller:"registerController"

    })
    .when("/detail", {
        templateUrl : "partials/details.html",
        controller:"detailController"
    })
    .when("/success", {
        templateUrl : "partials/success.html",
        controller:"detailController"
    })
    .otherwise({
            redirectTo: '/'
    });
});

app.controller("registerController", function($scope,$location,myFactory){
    $scope.homeaddress=false;
    $scope.companyaddress=false;
    $scope.choose=true;
    $scope.user={
        fname:" ",
        lname:" ",
        age:" ",
        email:" ",
        tel:" ",
        state:" ",
        country: " ",
        address1:" ",
        address2:" ",
        interests:" ",
        newsletter:" ",
        src:""
    };
    $scope.register=function(){
        $location.path("/form");
    };
    $scope.submit=function(){
       myFactory.setval($scope.user); 
       
        $location.path("/detail");
    };
    $scope.address_line=function(address_value){
        if(address_value=="home"){$scope.homeaddress=true;$scope.companyaddress=false;}
        if(address_value=="company"){$scope.companyaddress=true;$scope.homeaddress=false;}
    };
    $scope.range=function(val){
        var val= document.getElementById("range_value").value;
        console.log(val);
        if(val==2){$scope.user.age=13;}
        if(val==3){$scope.user.age=20;}
        if(val==4){$scope.user.age=30;}
        if(val>4){$scope.user.age=45;}
    };
    $scope.interest_fun=function(){
        $scope.arr=$scope.user.interests.split(",");
    };
    $scope.remove=function(val){
        var interest="";
        angular.forEach($scope.arr, function(value, key){
            if(value == val)
                $scope.arr.splice(key,1);
        });
        $scope.user.interests=$scope.arr.join();
    };
    $scope.readURL=function(input){
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#profile_pic').attr('src', e.target.result);
                $scope.user.src=$('#profile_pic').attr('src');      
            };
            reader.readAsDataURL(input.files[0]);
        }
        $scope.choose=false;
    };
});



app.controller("detailController",function($scope,$location,myFactory){
   $scope.user=myFactory.getval();
   $scope.choose=false;
   $scope.edit=false;
   $scope.editProfile=function(){
        $scope.edit=true;
        var cls=document.getElementsByClassName("detail_edit");
        for (var i = 0; i < cls.length; i++) {
            cls[i].style.color="red";
            cls[i].style.textDecoration="underline";
        }
   };
   $scope.editPhoto=function(){
        $scope.choose=true;
   };
   $scope.submit=function(){
        $location.path("/success");
   };
   $scope.readURL=function(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#detail_pic').attr('src', e.target.result);
                $scope.user.src=$('#profile_pic').attr('src');
            };
            reader.readAsDataURL(input.files[0]);
        }
        $scope.choose=false;
    }
});


